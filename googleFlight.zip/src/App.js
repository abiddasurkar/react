import React from 'react';
import { Box, Typography, Container, CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import Header from './components/Header/Header';
import FlightSearch from './components/FlightSearch/FlightSearch';
import BackgroundImage from './components/common/BackgroundImage';
import { FlightSearchProvider } from './components/context/FlightSearchContext';

// Create a responsive theme
const theme = createTheme({
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 960,
      lg: 1280,
      xl: 1920,
    },
  },
  typography: {
    fontFamily: '"Google Sans", "Roboto", "Arial", sans-serif',
    h2: {
      fontSize: '2.5rem',
      '@media (max-width:600px)': {
        fontSize: '2rem',
      },
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 24,
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 16,
        },
      },
    },
  },
});

const App = () => {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <FlightSearchProvider>
        <Box sx={{ flexGrow: 1, height: '100vh', overflow: 'hidden' }}>
          <Header />
          
          <Box 
            sx={{ 
              position: 'relative',
              height: 'calc(100vh - 64px)',
              background: 'linear-gradient(to bottom, #e8f0fe 0%, #e8f0fe 100%)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              pt: { xs: 2, sm: 4 }
            }}
          >
            <BackgroundImage />
            
            <Typography 
              variant="h2" 
              component="h1" 
              sx={{ 
                fontWeight: 400, 
                textAlign: 'center', 
                color: '#202124',
                mb: { xs: 2, sm: 4 },
                position: 'relative',
                zIndex: 2
              }}
            >
              Flights
            </Typography>
            
            <Container maxWidth="md" sx={{ position: 'relative', zIndex: 2 }}>
              <FlightSearch />
            </Container>
          </Box>
        </Box>
      </FlightSearchProvider>
    </ThemeProvider>
  );
};

export default App