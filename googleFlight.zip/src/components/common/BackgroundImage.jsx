import React from 'react';
import { Box, useMediaQuery, useTheme } from '@mui/material';

const BackgroundImage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  return (
    <Box 
      sx={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: isMobile ? '20%' : '50%',
        backgroundImage: `url(https://www.gstatic.com/travel-frontend/animation/hero/flights_nc_4.svg)`,
        backgroundSize: isMobile ? 'contain' : 'cover',
        backgroundPosition: 'center bottom',
        backgroundRepeat: 'no-repeat',
        '@media (prefers-color-scheme: dark)': {
          backgroundImage: `url(https://www.gstatic.com/travel-frontend/animation/hero/flights_nc_dark_theme_4.svg)`,
        }
      }}
    />
  );
};

export default BackgroundImage;