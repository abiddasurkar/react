import React from 'react';
import { Box, TextField, useMediaQuery, useTheme } from '@mui/material';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import DatePicker from '@mui/lab/DatePicker';
import { useFlightSearch } from '../context/FlightSearchContext';

const DateSelectors = ({ showReturn = true }) => {
  const { 
    departureDate, 
    setDepartureDate, 
    returnDate, 
    setReturnDate,
    tripType
  } = useFlightSearch();
  
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Convert string dates to Date objects
  const parseDateString = (dateStr) => {
    if (!dateStr) return null;
    return new Date(dateStr);
  };
  
  // Format Date objects to string (YYYY-MM-DD)
  const formatDateObject = (date) => {
    if (!date) return '';
    return date.toISOString().split('T')[0];
  };
  
  const departureDateObj = parseDateString(departureDate);
  const returnDateObj = parseDateString(returnDate);
  
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box sx={{ 
        display: 'flex', 
        flexDirection: isMobile ? 'column' : 'row',
        gap: 2
      }}>
        <DatePicker
          label="Departure"
          value={departureDateObj}
          onChange={(newDate) => {
            setDepartureDate(formatDateObject(newDate));
          }}
          disablePast
          slotProps={{
            textField: {
              fullWidth: true,
              variant: "outlined"
            }
          }}
        />
        
        {(showReturn || tripType === 'roundTrip') && (
          <DatePicker
            label="Return"
            value={returnDateObj}
            onChange={(newDate) => {
              setReturnDate(formatDateObject(newDate));
            }}
            disablePast
            minDate={departureDateObj || undefined}
            slotProps={{
              textField: {
                fullWidth: true,
                variant: "outlined"
              }
            }}
          />
        )}
      </Box>
    </LocalizationProvider>
  );
};

export default DateSelectors;