
// TripTypeSelector.jsx
import React from 'react';
import { Select, MenuItem, FormControl, InputLabel } from '@mui/material';
import { useFlightSearch } from '../context/FlightSearchContext';

const TripTypeSelector = () => {
  const { tripType, setTripType } = useFlightSearch();
  
  return (
    <FormControl variant="outlined" fullWidth>
      <Select
        value={tripType}
        onChange={(e) => setTripType(e.target.value)}
        displayEmpty
        variant="outlined"
      >
        <MenuItem value="roundTrip">Round trip</MenuItem>
        <MenuItem value="oneWay">One way</MenuItem>
        <MenuItem value="multiCity">Multi-city</MenuItem>
      </Select>
    </FormControl>
  );
};

export default TripTypeSelector;
