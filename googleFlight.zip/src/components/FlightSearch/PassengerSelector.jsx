
// PassengerSelector.jsx
import React from 'react';
import { Select, MenuItem, FormControl, Box, InputLabel } from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import { useFlightSearch } from '../context/FlightSearchContext';

const PassengerSelector = ({ type }) => {
  const { passengers, setPassengers, flightClass, setFlightClass } = useFlightSearch();
  
  if (type === 'passengers') {
    return (
      <FormControl variant="outlined" fullWidth>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <PersonIcon sx={{ mr: 1, color: 'text.secondary' }} />
          <Select
            value={passengers}
            onChange={(e) => setPassengers(e.target.value)}
            displayEmpty
            variant="outlined"
            fullWidth
          >
            {[1, 2, 3, 4, 5, 6].map(num => (
              <MenuItem key={num} value={num}>
                {num} {num === 1 ? 'passenger' : 'passengers'}
              </MenuItem>
            ))}
          </Select>
        </Box>
      </FormControl>
    );
  }
  
  return (
    <FormControl variant="outlined" fullWidth>
      <Select
        value={flightClass}
        onChange={(e) => setFlightClass(e.target.value)}
        displayEmpty
        variant="outlined"
        fullWidth
      >
        <MenuItem value="economy">Economy</MenuItem>
        <MenuItem value="premium">Premium economy</MenuItem>
        <MenuItem value="business">Business class</MenuItem>
        <MenuItem value="firstClass">First class</MenuItem>
      </Select>
    </FormControl>
  );
};

export default PassengerSelector;
