import React from 'react';
import { Button, CircularProgress } from '@mui/material';
import ExploreIcon from '@mui/icons-material/Explore';
import { useFlightSearch } from '../context/FlightSearchContext';

const SearchButton = () => {
  const { searchFlights, loading, error } = useFlightSearch();
  
  const handleSearch = async () => {
    try {
      await searchFlights();
    } catch (err) {
      // Error is already handled in context
      console.log('Search failed');
    }
  };
  
  return (
    <Button 
      variant="contained" 
      color="primary"
      fullWidth
      size="large"
      onClick={handleSearch}
      disabled={loading}
      startIcon={loading ? <CircularProgress size={20} color="inherit" /> : <ExploreIcon />}
      sx={{ 
        height: '100%', 
        minHeight: '56px',
        borderRadius: '24px',
        bgcolor: '#1a73e8',
        '&:hover': {
          bgcolor: '#1765cc',
        },
        '&.Mui-disabled': {
          bgcolor: '#a7c5f5',
          color: 'white'
        }
      }}
    >
      {loading ? 'Searching...' : 'Explore'}
    </Button>
  );
};

export default SearchButton;