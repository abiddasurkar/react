import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, 
  TextField, 
  IconButton, 
  InputAdornment, 
  useMediaQuery, 
  useTheme,
  Autocomplete,
  CircularProgress,
  Paper
} from '@mui/material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import SwapVertIcon from '@mui/icons-material/SwapVert';
import { useFlightSearch } from '../context/FlightSearchContext';

const LocationInputs = () => {
  const { 
    origin, 
    destination, 
    searchAirports, 
    selectOrigin, 
    selectDestination, 
    swapLocations, 
    loading,
    airports
  } = useFlightSearch();
  
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  const [originInput, setOriginInput] = useState('');
  const [destinationInput, setDestinationInput] = useState('');
  const [originOptions, setOriginOptions] = useState([]);
  const [destinationOptions, setDestinationOptions] = useState([]);
  
  const originDebounceTimer = useRef(null);
  const destinationDebounceTimer = useRef(null);
  
  // Handle origin input changes with debounce
  useEffect(() => {
    if (originInput.length < 2) {
      setOriginOptions([]);
      return;
    }
    
    clearTimeout(originDebounceTimer.current);
    originDebounceTimer.current = setTimeout(async () => {
      const results = await searchAirports(originInput);
      setOriginOptions(results);
    }, 500);
    
    return () => clearTimeout(originDebounceTimer.current);
  }, [originInput, searchAirports]);
  
  // Handle destination input changes with debounce
  useEffect(() => {
    if (destinationInput.length < 2) {
      setDestinationOptions([]);
      return;
    }
    
    clearTimeout(destinationDebounceTimer.current);
    destinationDebounceTimer.current = setTimeout(async () => {
      const results = await searchAirports(destinationInput);
      setDestinationOptions(results);
    }, 500);
    
    return () => clearTimeout(destinationDebounceTimer.current);
  }, [destinationInput, searchAirports]);
  
  // Render option helper function
  const renderOption = (props, option) => (
    <li {...props}>
      <Box sx={{ display: 'flex', flexDirection: 'column' }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <LocationOnIcon sx={{ mr: 1, fontSize: 20 }} />
          <strong>{option.name}</strong>
        </Box>
        <Box sx={{ ml: 4, fontSize: '0.8rem', color: 'text.secondary' }}>
          {option.city && `${option.city}, `}{option.country}
          {option.iata && ` (${option.iata})`}
        </Box>
      </Box>
    </li>
  );
  
  // Get option label helper function
  const getOptionLabel = (option) => {
    if (typeof option === 'string') return option;
    return option.name || option.iata || '';
  };
  
  if (isMobile) {
    // Vertical layout for mobile
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column' }}>
        <Autocomplete
          freeSolo
          options={originOptions}
          loading={loading}
          filterOptions={(x) => x}
          getOptionLabel={getOptionLabel}
          renderOption={renderOption}
          renderInput={(params) => (
            <TextField 
              {...params}
              placeholder="From where?"
              variant="outlined"
              InputProps={{
                ...params.InputProps,
                startAdornment: (
                  <InputAdornment position="start">
                    <LocationOnIcon color="action" />
                  </InputAdornment>
                ),
                endAdornment: (
                  <>
                    {loading ? <CircularProgress color="inherit" size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
          value={origin || null}
          inputValue={originInput}
          onInputChange={(_, newValue) => {
            setOriginInput(newValue);
          }}
          onChange={(_, newValue) => {
            if (newValue && typeof newValue !== 'string') {
              selectOrigin(newValue);
            }
          }}
          sx={{ mb: 1 }}
        />
        
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 1 }}>
          <IconButton onClick={swapLocations} aria-label="swap locations">
            <SwapVertIcon />
          </IconButton>
        </Box>
        
        <Autocomplete
          freeSolo
          options={destinationOptions}
          loading={loading}
          filterOptions={(x) => x}
          getOptionLabel={getOptionLabel}
          renderOption={renderOption}
          renderInput={(params) => (
            <TextField 
              {...params}
              placeholder="Where to?"
              variant="outlined"
              InputProps={{
                ...params.InputProps,
                startAdornment: (
                  <InputAdornment position="start">
                    <LocationOnIcon color="action" />
                  </InputAdornment>
                ),
                endAdornment: (
                  <>
                    {loading ? <CircularProgress color="inherit" size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
          value={destination || null}
          inputValue={destinationInput}
          onInputChange={(_, newValue) => {
            setDestinationInput(newValue);
          }}
          onChange={(_, newValue) => {
            if (newValue && typeof newValue !== 'string') {
              selectDestination(newValue);
            }
          }}
        />
      </Box>
    );
  }
  
  // Horizontal layout for desktop
  return (
    <Box sx={{ display: 'flex', alignItems: 'center' }}>
      <Autocomplete
        freeSolo
        options={originOptions}
        loading={loading}
        filterOptions={(x) => x}
        getOptionLabel={getOptionLabel}
        renderOption={renderOption}
        renderInput={(params) => (
          <TextField 
            {...params}
            placeholder="From where?"
            variant="outlined"
            fullWidth
            InputProps={{
              ...params.InputProps,
              startAdornment: (
                <InputAdornment position="start">
                  <LocationOnIcon color="action" />
                </InputAdornment>
              ),
              endAdornment: (
                <>
                  {loading ? <CircularProgress color="inherit" size={20} /> : null}
                  {params.InputProps.endAdornment}
                </>
              ),
            }}
          />
        )}
        value={origin || null}
        inputValue={originInput}
        onInputChange={(_, newValue) => {
          setOriginInput(newValue);
        }}
        onChange={(_, newValue) => {
          if (newValue && typeof newValue !== 'string') {
            selectOrigin(newValue);
          }
        }}
        sx={{ flex: 1 }}
      />
      
      <IconButton onClick={swapLocations} aria-label="swap locations" sx={{ mx: 1 }}>
        <SwapHorizIcon />
      </IconButton>
      
      <Autocomplete
        freeSolo
        options={destinationOptions}
        loading={loading}
        filterOptions={(x) => x}
        getOptionLabel={getOptionLabel}
        renderOption={renderOption}
        renderInput={(params) => (
          <TextField 
            {...params}
            placeholder="Where to?"
            variant="outlined"
            fullWidth
            InputProps={{
              ...params.InputProps,
              startAdornment: (
                <InputAdornment position="start">
                  <LocationOnIcon color="action" />
                </InputAdornment>
              ),
              endAdornment: (
                <>
                  {loading ? <CircularProgress color="inherit" size={20} /> : null}
                  {params.InputProps.endAdornment}
                </>
              ),
            }}
          />
        )}
        value={destination || null}
        inputValue={destinationInput}
        onInputChange={(_, newValue) => {
          setDestinationInput(newValue);
        }}
        onChange={(_, newValue) => {
          if (newValue && typeof newValue !== 'string') {
            selectDestination(newValue);
          }
        }}
        sx={{ flex: 1 }}
      />
    </Box>
  );
};

export default LocationInputs;