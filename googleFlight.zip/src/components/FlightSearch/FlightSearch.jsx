// FlightSearch.jsx
import React from 'react';
import { Box, Paper, Grid, Divider, useMediaQuery, useTheme } from '@mui/material';
import TripTypeSelector from './TripTypeSelector';
import PassengerSelector from './PassengerSelector';
import LocationInputs from './LocationInputs';
import DateSelectors from './DateSelectors';
import SearchButton from './SearchButton';
import { useFlightSearch } from '../context/FlightSearchContext';

const FlightSearch = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const { tripType } = useFlightSearch();
  
  return (
    <Paper 
      elevation={2} 
      sx={{ 
        borderRadius: 2, 
        overflow: 'hidden',
        width: '100%',
      }}
    >
      {/* Trip Type Selection */}
      <Box sx={{ px: 2, pt: 2 }}>
        <Grid container spacing={2} alignItems="center" flexWrap="wrap">
          <Grid item xs={12} sm="auto">
            <TripTypeSelector />
          </Grid>
          
          <Grid item xs={6} sm="auto">
            <PassengerSelector type="passengers" />
          </Grid>
          
          <Grid item xs={6} sm="auto">
            <PassengerSelector type="class" />
          </Grid>
        </Grid>
      </Box>
      
      <Divider sx={{ my: 2 }} />
      
      {/* Search Fields */}
      <Box sx={{ px: 2, pb: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={5}>
            <LocationInputs />
          </Grid>
          
          <Grid item xs={12} md={5}>
            <DateSelectors showReturn={tripType === 'roundTrip'} />
          </Grid>
          
          <Grid item xs={12} md={2}>
            <SearchButton />
          </Grid>
        </Grid>
      </Box>
    </Paper>
  );
};

export default FlightSearch;
