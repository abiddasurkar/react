
// ProfileMenu.jsx
import React from 'react';
import { IconButton } from '@mui/material';

const ProfileMenu = () => {
  return (
    <IconButton color="inherit">
      <img 
        src="https://ssl.gstatic.com/ui/v1/icons/mail/profile_mask2.png" 
        alt="Profile" 
        style={{ width: 32, height: 32, borderRadius: '50%' }}
      />
    </IconButton>
  );
};

export default ProfileMenu;