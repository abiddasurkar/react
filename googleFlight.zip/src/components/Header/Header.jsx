// Header.jsx
import React from 'react';
import { AppBar, Toolbar, IconButton, Box } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import NavigationLinks from './NavigationLinks';
import ProfileMenu from './ProfileMenu';

const Header = () => {
  return (
    <AppBar position="static" color="default" elevation={0} sx={{ backgroundColor: 'white' }}>
      <Toolbar sx={{ flexWrap: 'wrap' }}>
        <IconButton 
          edge="start" 
          color="inherit" 
          aria-label="menu" 
          sx={{ mr: 2, display: { xs: 'block', sm: 'none' } }}
        >
          <MenuIcon />
        </IconButton>
        
        <img 
          src="https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_74x24dp.png" 
          alt="Google" 
          style={{ height: 24 }}
        />
        
        <NavigationLinks />
        
        <Box sx={{ flexGrow: 1 }} />
        
        <ProfileMenu />
      </Toolbar>
    </AppBar>
  );
};

export default Header;
