
// NavigationLinks.jsx
import React from 'react';
import { Box, Button, useMediaQuery, useTheme, IconButton, Menu, MenuItem } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ExploreIcon from '@mui/icons-material/Explore';
import FlightIcon from '@mui/icons-material/Flight';
import HotelIcon from '@mui/icons-material/Hotel';
import HomeIcon from '@mui/icons-material/Home';
import MoreVertIcon from '@mui/icons-material/MoreVert';

const NavigationLinks = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [anchorEl, setAnchorEl] = React.useState(null);
  
  const handleOpenMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };
  
  const handleCloseMenu = () => {
    setAnchorEl(null);
  };
  
  const navLinks = [
    { icon: <SearchIcon />, label: 'Travel', active: false },
    { icon: <ExploreIcon />, label: 'Explore', active: false },
    { icon: <FlightIcon />, label: 'Flights', active: true },
    { icon: <HotelIcon />, label: 'Hotels', active: false },
    { icon: <HomeIcon />, label: 'Vacation rentals', active: false },
  ];
  
  if (isMobile) {
    // Mobile view - show fewer buttons and a menu for the rest
    return (
      <Box sx={{ display: 'flex', ml: 2, alignItems: 'center' }}>
        <Button 
          startIcon={<FlightIcon />} 
          sx={{ 
            mr: 1, 
            textTransform: 'none', 
            bgcolor: 'rgba(232, 240, 254, 1)', 
            color: 'black',
            display: { xs: 'flex', sm: 'flex' }
          }}
        >
          Flights
        </Button>
        
        <IconButton 
          onClick={handleOpenMenu}
          sx={{ display: { xs: 'flex', md: 'none' } }}
        >
          <MoreVertIcon />
        </IconButton>
        
        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleCloseMenu}
        >
          {navLinks.filter(link => !link.active).map((link) => (
            <MenuItem key={link.label} onClick={handleCloseMenu}>
              {link.icon} {link.label}
            </MenuItem>
          ))}
        </Menu>
      </Box>
    );
  }
  
  // Desktop view - show all buttons
  return (
    <Box sx={{ display: 'flex', ml: 2 }}>
      {navLinks.map((link) => (
        <Button 
          key={link.label}
          startIcon={link.icon} 
          sx={{ 
            mr: 1, 
            textTransform: 'none',
            ...(link.active ? { 
              bgcolor: 'rgba(232, 240, 254, 1)', 
              color: 'black' 
            } : {})
          }}
        >
          {link.label}
        </Button>
      ))}
    </Box>
  );
};

export default NavigationLinks;
