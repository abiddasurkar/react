import React, { createContext, useContext, useState, useEffect } from 'react';
import { airportService, flightService, systemService } from '../../services/api';

// Create context
const FlightSearchContext = createContext();

// Custom hook to use the flight search context
export const useFlightSearch = () => useContext(FlightSearchContext);

// Provider component
export const FlightSearchProvider = ({ children }) => {
  // State for flight search
  const [tripType, setTripType] = useState('roundTrip');
  const [passengers, setPassengers] = useState({
    adults: 1,
    children: 0,
    infants: 0
  });
  const [flightClass, setFlightClass] = useState('economy');
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [departureDate, setDepartureDate] = useState('');
  const [returnDate, setReturnDate] = useState('');
  
  // API related states
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [airports, setAirports] = useState([]);
  const [searchResults, setSearchResults] = useState(null);
  const [currency, setCurrency] = useState('USD');
  const [locale, setLocale] = useState('en-US');
  const [originEntity, setOriginEntity] = useState(null);
  const [destinationEntity, setDestinationEntity] = useState(null);
  
  // Initialize locale from API
  useEffect(() => {
    const initializeLocale = async () => {
      try {
        const localeData = await systemService.getLocale();
        if (localeData && localeData.locale) {
          setLocale(localeData.locale);
        }
      } catch (err) {
        console.error('Failed to initialize locale:', err);
      }
    };
    
    initializeLocale();
  }, []);

  // Function to search airports
  const searchAirports = async (query) => {
    if (!query || query.length < 2) return [];
    
    setLoading(true);
    setError(null);
    
    try {
      const results = await airportService.searchAirport(query, locale);
      setAirports(results.data || []);
      return results.data || [];
    } catch (err) {
      setError('Failed to search airports');
      console.error('Airport search error:', err);
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Function to set origin with entity data
  const selectOrigin = (airportData) => {
    setOrigin(airportData.name || airportData.id);
    setOriginEntity({
      skyId: airportData.skyId,
      entityId: airportData.entityId
    });
  };

  // Function to set destination with entity data
  const selectDestination = (airportData) => {
    setDestination(airportData.name || airportData.id);
    setDestinationEntity({
      skyId: airportData.skyId,
      entityId: airportData.entityId
    });
  };

  // Function to swap origin and destination
  const swapLocations = () => {
    const tempName = origin;
    const tempEntity = originEntity;
    
    setOrigin(destination);
    setOriginEntity(destinationEntity);
    
    setDestination(tempName);
    setDestinationEntity(tempEntity);
  };

  // Function to search flights using the API
  const searchFlights = async () => {
    if (!originEntity?.skyId || !destinationEntity?.skyId || !departureDate) {
      setError('Missing required flight search parameters');
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const searchParams = {
        originSkyId: originEntity.skyId,
        destinationSkyId: destinationEntity.skyId,
        originEntityId: originEntity.entityId,
        destinationEntityId: destinationEntity.entityId,
        date: departureDate,
        adults: passengers.adults,
        children: passengers.children,
        infants: passengers.infants,
        cabinClass: flightClass,
        currency: currency,
        market: locale,
        countryCode: locale.split('-')[1] || 'US'
      };
      
      // Add returnDate for round trips
      if (tripType === 'roundTrip' && returnDate) {
        searchParams.returnDate = returnDate;
      }

      const results = await flightService.searchFlights(searchParams);
      setSearchResults(results);
      return results;
    } catch (err) {
      setError('Failed to search flights');
      console.error('Flight search error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Function to get price calendar
  const getFlightPriceCalendar = async () => {
    if (!originEntity?.skyId || !destinationEntity?.skyId) {
      setError('Missing origin or destination for price calendar');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const currentDate = new Date().toISOString().split('T')[0];
      const results = await flightService.getPriceCalendar(
        originEntity.skyId,
        destinationEntity.skyId,
        currentDate,
        currency
      );
      return results;
    } catch (err) {
      setError('Failed to get price calendar');
      console.error('Price calendar error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Function to get flight details
  const getFlightDetails = async (legs) => {
    if (!legs) {
      setError('Missing legs for flight details');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const detailParams = {
        legs,
        adults: passengers.adults,
        currency,
        locale,
        cabinClass: flightClass,
        countryCode: locale.split('-')[1] || 'US'
      };
      
      const details = await flightService.getFlightDetails(detailParams);
      return details;
    } catch (err) {
      setError('Failed to get flight details');
      console.error('Flight details error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Context value
  const value = {
    // Search state
    tripType, setTripType,
    passengers, setPassengers,
    flightClass, setFlightClass,
    origin, setOrigin,
    destination, setDestination,
    departureDate, setDepartureDate,
    returnDate, setReturnDate,
    
    // API related state
    loading,
    error,
    airports,
    searchResults,
    currency, setCurrency,
    locale, setLocale,
    
    // Functions
    swapLocations,
    searchFlights,
    searchAirports,
    selectOrigin,
    selectDestination,
    getFlightPriceCalendar,
    getFlightDetails
  };

  return (
    <FlightSearchContext.Provider value={value}>
      {children}
    </FlightSearchContext.Provider>
  );
};