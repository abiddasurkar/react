import React, { useState } from 'react';
import { 
  AppBar, 
  Toolbar, 
  IconButton, 
  Box, 
  Container, 
  Typography, 
  Paper, 
  Grid,
  TextField,
  Button,
  Tab,
  Tabs,
  InputAdornment,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Divider
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import FlightIcon from '@mui/icons-material/Flight';
import HotelIcon from '@mui/icons-material/Hotel';
import HomeIcon from '@mui/icons-material/Home';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import PersonIcon from '@mui/icons-material/Person';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import ExploreIcon from '@mui/icons-material/Explore';

const GoogleFlightsClone = () => {
  const [tripType, setTripType] = useState('roundTrip');
  const [passengers, setPassengers] = useState(1);
  const [flightClass, setFlightClass] = useState('economy');
  
  return (
    <Box sx={{ flexGrow: 1, height: '100vh', overflow: 'hidden' }}>
      {/* Header */}
      <AppBar position="static" color="default" elevation={0} sx={{ backgroundColor: 'white' }}>
        <Toolbar>
          <IconButton edge="start" color="inherit" aria-label="menu" sx={{ mr: 2 }}>
            <MenuIcon />
          </IconButton>
          <img src="https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_74x24dp.png" alt="Google" />
          
          <Box sx={{ display: 'flex', ml: 2 }}>
            <Button startIcon={<SearchIcon />} sx={{ mr: 1, textTransform: 'none' }}>
              Travel
            </Button>
            <Button startIcon={<ExploreIcon />} sx={{ mr: 1, textTransform: 'none' }}>
              Explore
            </Button>
            <Button 
              startIcon={<FlightIcon />} 
              sx={{ mr: 1, textTransform: 'none', bgcolor: 'rgba(232, 240, 254, 1)', color: 'black' }}
            >
              Flights
            </Button>
            <Button startIcon={<HotelIcon />} sx={{ mr: 1, textTransform: 'none' }}>
              Hotels
            </Button>
            <Button startIcon={<HomeIcon />} sx={{ textTransform: 'none' }}>
              Vacation rentals
            </Button>
          </Box>
          
          <Box sx={{ flexGrow: 1 }} />
          
          <IconButton color="inherit">
            <img 
              src="https://ssl.gstatic.com/ui/v1/icons/mail/profile_mask2.png" 
              alt="Profile" 
              style={{ width: 32, height: 32, borderRadius: '50%' }}
            />
          </IconButton>
        </Toolbar>
      </AppBar>
      
      {/* Background with winter scene */}
      <Box 
        sx={{ 
          position: 'relative',
          height: 'calc(100vh - 64px)',
          background: 'linear-gradient(to bottom, #e8f0fe 0%, #e8f0fe 100%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          pt: 4
        }}
      >
        {/* Background image - styled like the Google Flights background */}
        <Box 
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: '50%',
            backgroundImage: `url(https://www.gstatic.com/travel-frontend/animation/hero/flights_nc_4.svg)`,
            backgroundSize: 'cover',
            backgroundPosition: 'center bottom',
            backgroundRepeat: 'no-repeat',
            '@media (prefers-color-scheme: dark)': {
              backgroundImage: `url(https://www.gstatic.com/travel-frontend/animation/hero/flights_nc_dark_theme_4.svg)`,
            }
          }}
        />
        
        {/* Title */}
        <Typography 
          variant="h2" 
          component="h1" 
          sx={{ 
            fontWeight: 400, 
            textAlign: 'center', 
            color: '#202124',
            mb: 4,
            position: 'relative',
            zIndex: 2
          }}
        >
          Flights
        </Typography>
        
        {/* Search Box */}
        <Container maxWidth="md" sx={{ position: 'relative', zIndex: 2 }}>
          <Paper elevation={2} sx={{ borderRadius: 2, overflow: 'hidden' }}>
            {/* Trip Type Selection */}
            <Box sx={{ px: 2, pt: 2 }}>
              <Grid container spacing={2} alignItems="center">
                <Grid item>
                  <Select
                    value={tripType}
                    onChange={(e) => setTripType(e.target.value)}
                    displayEmpty
                    variant="outlined"
                    sx={{ minWidth: 120 }}
                  >
                    <MenuItem value="roundTrip">Round trip</MenuItem>
                    <MenuItem value="oneWay">One way</MenuItem>
                    <MenuItem value="multiCity">Multi-city</MenuItem>
                  </Select>
                </Grid>
                
                <Grid item>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <PersonIcon sx={{ mr: 1, color: 'text.secondary' }} />
                    <Select
                      value={passengers}
                      onChange={(e) => setPassengers(e.target.value)}
                      displayEmpty
                      variant="outlined"
                    >
                      {[1, 2, 3, 4, 5, 6].map(num => (
                        <MenuItem key={num} value={num}>{num}</MenuItem>
                      ))}
                    </Select>
                  </Box>
                </Grid>
                
                <Grid item>
                  <Select
                    value={flightClass}
                    onChange={(e) => setFlightClass(e.target.value)}
                    displayEmpty
                    variant="outlined"
                    sx={{ minWidth: 120 }}
                  >
                    <MenuItem value="economy">Economy</MenuItem>
                    <MenuItem value="premium">Premium economy</MenuItem>
                    <MenuItem value="business">Business class</MenuItem>
                    <MenuItem value="firstClass">First class</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            </Box>
            
            <Divider sx={{ my: 2 }} />
            
            {/* Search Fields */}
            <Box sx={{ px: 2, pb: 2 }}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={5}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TextField 
                      placeholder="Pune"
                      variant="outlined"
                      fullWidth
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <LocationOnIcon color="action" />
                          </InputAdornment>
                        ),
                      }}
                    />
                    <IconButton aria-label="swap locations" sx={{ mx: 1 }}>
                      <SwapHorizIcon />
                    </IconButton>
                    <TextField 
                      placeholder="Where to?"
                      variant="outlined"
                      fullWidth
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <LocationOnIcon color="action" />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={5}>
                  <Box sx={{ display: 'flex' }}>
                    <TextField 
                      placeholder="Departure"
                      variant="outlined"
                      fullWidth
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <CalendarTodayIcon color="action" />
                          </InputAdornment>
                        ),
                      }}
                    />
                    <Box sx={{ mx: 1 }} />
                    <TextField 
                      placeholder="Return"
                      variant="outlined"
                      fullWidth
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <CalendarTodayIcon color="action" />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={2}>
                  <Button 
                    variant="contained" 
                    color="primary"
                    fullWidth
                    size="large"
                    startIcon={<ExploreIcon />}
                    sx={{ 
                      height: '100%', 
                      borderRadius: '24px',
                      bgcolor: '#1a73e8',
                      '&:hover': {
                        bgcolor: '#1765cc',
                      }
                    }}
                  >
                    Explore
                  </Button>
                </Grid>
              </Grid>
            </Box>
          </Paper>
        </Container>
      </Box>
    </Box>
  );
};

export default GoogleFlightsClone;