import axios from 'axios';

// Base configuration
const API_BASE_URL = 'https://sky-scrapper.p.rapidapi.com';
const API_KEY = '3535583cdfmsha6c7b226564a251p155a79jsncf45b3d4f53c'; // Replace with your actual API key

// Create axios instance with common configuration
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'x-rapidapi-key': API_KEY,
    'x-rapidapi-host': 'sky-scrapper.p.rapidapi.com'
  }
});

// System API services
export const systemService = {
  // Get locale information
  getLocale: async () => {
    try {
      const response = await apiClient.get('/api/v1/getLocale');
      return response.data;
    } catch (error) {
      console.error('Error getting locale:', error);
      throw error;
    }
  },

  // Check server status
  checkServer: async () => {
    try {
      const response = await apiClient.get('/api/v1/checkServer');
      return response.data;
    } catch (error) {
      console.error('Error checking server:', error);
      throw error;
    }
  },

  // Get configuration
  getConfig: async () => {
    try {
      const response = await apiClient.get('/api/v1/getConfig');
      return response.data;
    } catch (error) {
      console.error('Error getting config:', error);
      throw error;
    }
  }
};

// Airport API services
export const airportService = {
  // Search airports by query (city, airport name, etc.)
  searchAirport: async (query, locale = 'en-US') => {
    try {
      const response = await apiClient.get('/api/v1/flights/searchAirport', {
        params: { query, locale }
      });
      return response.data;
    } catch (error) {
      console.error('Error searching airports:', error);
      throw error;
    }
  },

  // Get nearby airports by latitude and longitude
  getNearbyAirports: async (lat, lng, locale = 'en-US') => {
    try {
      const response = await apiClient.get('/api/v1/flights/getNearByAirports', {
        params: { lat, lng, locale }
      });
      return response.data;
    } catch (error) {
      console.error('Error getting nearby airports:', error);
      throw error;
    }
  }
};

// Flight API services
export const flightService = {
  // Search one-way or return flights
  searchFlights: async (params) => {
    try {
      const {
        originSkyId,
        destinationSkyId,
        originEntityId,
        destinationEntityId,
        date,
        returnDate,
        adults = 1,
        cabinClass = 'economy',
        sortBy = 'best',
        children = 0,
        infants = 0,
        currency = 'USD',
        market = 'en-US',
        countryCode = 'US'
      } = params;

      // Validate required parameters
      if (!originSkyId || !destinationSkyId) {
        throw new Error('Missing required flight search parameters');
      }

      const response = await apiClient.get('/api/v2/flights/searchFlights', {
        params: {
          originSkyId,
          destinationSkyId,
          originEntityId,
          destinationEntityId,
          date,
          returnDate,
          adults,
          cabinClass,
          sortBy,
          children,
          infants,
          currency,
          market,
          countryCode
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error searching flights:', error);
      throw error;
    }
  },

  // Get detailed flight information
  getFlightDetails: async (params) => {
    try {
      const {
        legs,
        adults = 1,
        currency = 'USD',
        locale = 'en-US',
        market = 'en-US',
        cabinClass = 'economy',
        countryCode = 'US'
      } = params;

      if (!legs) {
        throw new Error('Missing required legs parameter');
      }

      const response = await apiClient.get('/api/v1/flights/getFlightDetails', {
        params: {
          legs: typeof legs === 'string' ? legs : JSON.stringify(legs),
          adults,
          currency,
          locale,
          market,
          cabinClass,
          countryCode
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error getting flight details:', error);
      throw error;
    }
  },

  // Search multi-stop flights
  searchFlightsMultiStops: async (params) => {
    try {
      const {
        legs,
        cabinClass = 'economy',
        adults = 1,
        sortBy = 'best',
        currency = 'USD',
        countryCode = 'US',
        market = 'en-US'
      } = params;

      if (!legs) {
        throw new Error('Missing required legs parameter');
      }

      const response = await apiClient.get('/api/v1/flights/searchFlightsMultiStops', {
        params: {
          legs: typeof legs === 'string' ? legs : JSON.stringify(legs),
          cabinClass,
          adults,
          sortBy,
          currency,
          countryCode,
          market
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error searching multi-stop flights:', error);
      throw error;
    }
  },

  // Get price calendar for flights
  getPriceCalendar: async (originSkyId, destinationSkyId, fromDate, currency = 'USD') => {
    try {
      if (!originSkyId || !destinationSkyId || !fromDate) {
        throw new Error('Missing required parameters for price calendar');
      }

      const response = await apiClient.get('/api/v1/flights/getPriceCalendar', {
        params: {
          originSkyId,
          destinationSkyId,
          fromDate,
          currency
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error getting price calendar:', error);
      throw error;
    }
  },

  // Search flights to anywhere (everywhere)
  searchFlightEverywhere: async (params) => {
    try {
      const {
        originEntityId,
        cabinClass = 'economy',
        journeyType = 'one_way',
        currency = 'USD'
      } = params;

      if (!originEntityId) {
        throw new Error('Missing required originEntityId parameter');
      }

      const response = await apiClient.get('/api/v2/flights/searchFlightEverywhere', {
        params: {
          originEntityId,
          cabinClass,
          journeyType,
          currency
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error searching flights everywhere:', error);
      throw error;
    }
  },

  // Search flights with web complete info
  searchFlightsWebComplete: async (params) => {
    try {
      const {
        originSkyId,
        destinationSkyId,
        originEntityId,
        destinationEntityId,
        cabinClass = 'economy',
        adults = 1,
        sortBy = 'best',
        currency = 'USD',
        market = 'en-US',
        countryCode = 'US'
      } = params;

      if (!originSkyId || !destinationSkyId) {
        throw new Error('Missing required flight search parameters');
      }

      const response = await apiClient.get('/api/v2/flights/searchFlightsWebComplete', {
        params: {
          originSkyId,
          destinationSkyId,
          originEntityId,
          destinationEntityId,
          cabinClass,
          adults,
          sortBy,
          currency,
          market,
          countryCode
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error searching flights with web complete:', error);
      throw error;
    }
  }
};

// Export all services
export default {
  systemService,
  airportService,
  flightService
};